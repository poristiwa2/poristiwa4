import { categories } from '../data/mockData';

interface FooterProps {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-navy text-gray-300">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <button onClick={() => onNavigate('home')} className="flex items-center gap-1.5 mb-4">
              <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
                <span className="text-white font-black text-lg font-serif">P</span>
              </div>
              <span className="text-lg font-black tracking-tight text-white">
                PORI<span className="text-brand">STIWA</span>
              </span>
            </button>
            <p className="text-sm text-gray-400 leading-relaxed mb-4">
              Portal berita terkini, terpercaya, dan terlengkap. Menyajikan informasi berkualitas dari berbagai sumber tepercaya untuk masyarakat Indonesia.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-brand transition" aria-label="Twitter">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
              </a>
              <a href="#" className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-brand transition" aria-label="Facebook">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </a>
              <a href="#" className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-brand transition" aria-label="Instagram">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
              </a>
            </div>
          </div>

          {/* Kategori */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4 uppercase tracking-wider">Kategori</h4>
            <ul className="space-y-2">
              {categories.slice(0, 6).map(cat => (
                <li key={cat.id}>
                  <button
                    onClick={() => onNavigate('category', { slug: cat.slug })}
                    className="text-sm text-gray-400 hover:text-white transition"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Lainnya */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4 uppercase tracking-wider">Lainnya</h4>
            <ul className="space-y-2">
              {categories.slice(6).map(cat => (
                <li key={cat.id}>
                  <button
                    onClick={() => onNavigate('category', { slug: cat.slug })}
                    className="text-sm text-gray-400 hover:text-white transition"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Info */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4 uppercase tracking-wider">Informasi</h4>
            <ul className="space-y-2">
              <li><button onClick={() => onNavigate('tentang')} className="text-sm text-gray-400 hover:text-white transition">Tentang Kami</button></li>
              <li><button onClick={() => onNavigate('redaksi')} className="text-sm text-gray-400 hover:text-white transition">Dewan Redaksi</button></li>
              <li><button onClick={() => onNavigate('kontak')} className="text-sm text-gray-400 hover:text-white transition">Hubungi Kami</button></li>
              <li><button onClick={() => onNavigate('privasi')} className="text-sm text-gray-400 hover:text-white transition">Kebijakan Privasi</button></li>
              <li><button onClick={() => onNavigate('pedoman')} className="text-sm text-gray-400 hover:text-white transition">Pedoman Media Siber</button></li>
              <li><button onClick={() => onNavigate('sitemap')} className="text-sm text-gray-400 hover:text-white transition">Peta Situs</button></li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <p className="text-xs text-gray-500">
            &copy; {new Date().getFullYear()} Poristiwa.my.id — Seluruh hak cipta dilindungi undang-undang.
          </p>
          <p className="text-xs text-gray-500">
            Anggota <span className="text-gray-400">Dewan Pers Indonesia</span> &bull; Terverifikasi Faktual
          </p>
        </div>
      </div>
    </footer>
  );
}
